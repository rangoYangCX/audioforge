public enum AudioEventID
{
    btn_click_group_1,
    card_shake_group_1,
    card_sorted_into_slot_successfully_group_1,
    card_sorted_into_slot_successfully_home_empty_group_1,
    card_sorted_into_slot_successfully_home_multi_group_1,
    card_sorted_into_slot_successfully_home_one_group_1,
    flip_the_card_group_1,
    restore_the_card_group_1,
    settlement_1_group_1,
    tap_to_move_the_card_group_1
}
